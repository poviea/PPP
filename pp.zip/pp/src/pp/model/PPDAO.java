package pp.model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import guestbook.model.PPBEAN;
import util.DBUtil;

public class PPDAO {
//	public static boolean writeContent(PPBEAN vo) throws SQLException{
//		Connection con = null;	
//		PreparedStatement pstmt = null;
//		boolean result = false;
//		
//		try {
//			con = DBUtil.getConnection();
//			pstmt = con.prepareStatement("select * from test;");
//
//	        pstmt.setString(1, vo.getGrade());
//	        
//			int count = pstmt.executeUpdate();			
//			if(count != 0){
//				result = true;
//			}
//			
//		}finally{
//			DBUtil.close(con, pstmt);
//		}
//		return result;		
//	}
	
	public static ArrayList<PPBEAN> getAllDept() throws SQLException{
		// 2단계 : DB연결
		Connection con = null; 
		Statement stmt = null;
		ResultSet rset = null; // SELECT문 할때만 사용 
		
		ArrayList<PPBEAN> allData;
		try {
//			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/scott?serverTimezone=Asia/Seoul", "scott", "tiger");
			con = DBUtil.getConnection();
			// 3단계 : SQL 문장 객체(Statement)
			stmt = con.createStatement();
			
			// 4단계 : SQL 실행(DB에서 SELECT * FROM dept;) -> 반환된 결과를 담을 수 있는 객체(ResultSet) 필요
			rset = stmt.executeQuery("SELECT * FROM DEPT;");
			
			allData = new ArrayList<PPBEAN>();
			while(rset.next()) {
				// 5단계 : 데이터의 활용(검색)
				allData.add(new PPBEAN(rset.getInt("deptno"), 0, rset.getString("dname"), rset.getString("loc"), null, 0));				
			}
		
			// 6단계 : DB 종료(자원 반환)
		} finally {
//			rset.close();
//			stmt.close();
//			con.close();
			DBUtil.close(con, stmt, rset);
		}
		
		return allData;
		
	}
	
	public static void main(String[] args) {
		try {
			for(PPBEAN dept: getAllDept()) {
			System.out.println(dept);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
