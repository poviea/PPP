package guestbook.model;

// Bean == DTO
public class PPBEAN {
	private int empno;					// 글 번호
	private int deptno;			
	private String pw;				// 글 작성자
	private String ename;				// 글 작성자 전자메일
	private String grade;			
	private int mgr;
	public int getEmpno() {
		return empno;
	}
	public void setEmpno(int empno) {
		this.empno = empno;
	}
	public int getDeptno() {
		return deptno;
	}
	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public int getMgr() {
		return mgr;
	}
	public void setMgr(int mgr) {
		this.mgr = mgr;
	}
	@Override
	public String toString() {
		return "PPBEAN [empno=" + empno + ", deptno=" + deptno + ", pw=" + pw + ", ename=" + ename + ", grade=" + grade
				+ ", mgr=" + mgr + "]";
	}
	public PPBEAN(int empno, int deptno, String pw, String ename, String grade, int mgr) {
		super();
		this.empno = empno;
		this.deptno = deptno;
		this.pw = pw;
		this.ename = ename;
		this.grade = grade;
		this.mgr = mgr;
	}	
	
	

}
