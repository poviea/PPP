package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class select {

	public static void main(String[] args) {
		Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try{
            Class.forName("com.mysql.jdbc.Driver");

            String url = "jdbc:mysql://localhost/pp?serverTimezone=Asia/Seoul";
            conn = DriverManager.getConnection(url, "root", "root");

            stmt = conn.createStatement();

       
            String sql = "SELECT * FROM test;";


            rs = stmt.executeQuery(sql);

            while(rs.next()){
                String name = rs.getString(1);
                String owner = rs.getString(2);
                String date = rs.getString(3);
                String aa = rs.getString(4);
                String bb = rs.getString(5);
                String cc = rs.getString(6);

                
                System.out.println(name + " " + owner + " " + date + " " + aa + " " + bb + " " + cc);
            }
        }
        catch( ClassNotFoundException e){
            System.out.println("드라이버 로딩 실패");
        }
        catch( SQLException e){
            System.out.println("에러 " + e);
        }
        finally{
            try{
                if( conn != null && !conn.isClosed()){
                    conn.close();
                }
                if( stmt != null && !stmt.isClosed()){
                    stmt.close();
                }
                if( rs != null && !rs.isClosed()){
                    rs.close();
                }
            }
            catch( SQLException e){
                e.printStackTrace();
            }
        }
	}

}